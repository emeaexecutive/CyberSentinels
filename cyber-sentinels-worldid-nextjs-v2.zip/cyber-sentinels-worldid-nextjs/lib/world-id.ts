export const WORLD_ACTION_ID = process.env.WORLD_ACTION_ID ?? "cyber_sentinels_verify_human";
export const WORLD_VERIFY_BASE_URL = process.env.WORLD_VERIFY_BASE_URL ?? "https://staging-developer.world.org";

export function requiredEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export type CyberSentinelsWorldIdVerification = {
  verified: boolean;
  trustSignal: "world_id_proof_of_human";
  trustScoreContribution: number;
  nullifierHash?: string;
  reason?: string;
  raw?: unknown;
};
