"use client";

import { useMemo, useState } from "react";
import { IDKitWidget, VerificationLevel, ISuccessResult } from "@worldcoin/idkit";

const APP_ID = process.env.NEXT_PUBLIC_WORLD_APP_ID;
const ACTION = process.env.NEXT_PUBLIC_WORLD_ACTION_ID ?? "cyber_sentinels_verify_human";

type VerificationState =
  | { status: "idle" }
  | { status: "loading"; message: string }
  | { status: "success"; message: string; nullifierHash?: string }
  | { status: "error"; message: string };

function makeSignal(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export default function WorldIdProofOfHuman() {
  const [state, setState] = useState<VerificationState>({ status: "idle" });
  const signal = useMemo(() => makeSignal(), []);

  async function verifyProof(proof: ISuccessResult) {
    setState({ status: "loading", message: "Verifying proof with Cyber Sentinels backend..." });

    const response = await fetch("/api/world-id/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ proof, signal }),
    });

    const data = await response.json();

    if (!response.ok || !data?.verified) {
      setState({ status: "error", message: data?.reason ?? "Proof verification failed." });
      return;
    }

    setState({
      status: "success",
      message: "World ID proof-of-human verified. Cyber Sentinels trust signal accepted.",
      nullifierHash: data.nullifierHash,
    });
  }

  if (!APP_ID) {
    return (
      <div className="rounded-3xl border border-red-400/30 bg-red-500/10 p-5 text-red-100">
        Missing NEXT_PUBLIC_WORLD_APP_ID. Add it in Vercel Project Settings → Environment Variables.
      </div>
    );
  }

  return (
    <div className="rounded-[32px] border border-white/10 bg-white/[0.04] p-6 backdrop-blur-xl">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-emerald-300">Proof of Human</p>
          <h2 className="mt-2 text-3xl font-semibold">World ID Trust Signal</h2>
          <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-300">
            Cyber Sentinels uses World ID as one privacy-preserving proof-of-human signal, then combines it with device,
            session, policy and audit data to produce a composite trust decision.
          </p>
        </div>

        <IDKitWidget
          app_id={APP_ID as `app_${string}`}
          action={ACTION}
          signal={signal}
          verification_level={VerificationLevel.Orb}
          handleVerify={verifyProof}
          onSuccess={() => undefined}
        >
          {({ open }) => (
            <button onClick={open} className="rounded-full bg-white px-6 py-3 font-semibold text-black hover:opacity-90">
              Verify with World ID
            </button>
          )}
        </IDKitWidget>
      </div>

      <div className="mt-6 rounded-3xl border border-white/10 bg-black/20 p-5">
        <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Session Signal</p>
        <p className="mt-2 break-all text-sm text-slate-300">{signal}</p>
      </div>

      {state.status !== "idle" && (
        <div
          className={`mt-6 rounded-3xl border p-5 ${
            state.status === "success"
              ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-100"
              : state.status === "error"
                ? "border-red-400/30 bg-red-500/10 text-red-100"
                : "border-cyan-400/30 bg-cyan-500/10 text-cyan-100"
          }`}
        >
          <p className="font-medium">{state.message}</p>
          {state.status === "success" && state.nullifierHash && (
            <p className="mt-3 break-all text-xs opacity-80">Nullifier: {state.nullifierHash}</p>
          )}
        </div>
      )}
    </div>
  );
}
