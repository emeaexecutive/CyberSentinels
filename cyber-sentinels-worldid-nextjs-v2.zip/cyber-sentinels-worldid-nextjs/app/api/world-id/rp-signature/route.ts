import { NextResponse } from "next/server";
import { signRequest } from "@worldcoin/idkit-core/signing";
import { requiredEnv, WORLD_ACTION_ID } from "@/lib/world-id";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const action = body.action ?? WORLD_ACTION_ID;
    const rpId = requiredEnv("WORLD_RP_ID");
    const signingKey = requiredEnv("WORLD_RP_SIGNING_KEY");

    const rpContext = await signRequest({
      rp_id: rpId,
      action,
      signal: body.signal,
      signing_key: signingKey,
    });

    return NextResponse.json({ rpContext });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not generate RP signature.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
