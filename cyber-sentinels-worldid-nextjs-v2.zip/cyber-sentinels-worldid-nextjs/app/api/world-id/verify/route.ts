import { NextResponse } from "next/server";
import { sql } from "@vercel/postgres";
import { requiredEnv, WORLD_ACTION_ID, WORLD_VERIFY_BASE_URL, CyberSentinelsWorldIdVerification } from "@/lib/world-id";

export const runtime = "nodejs";

type WorldIdVerifyBody = {
  proof: Record<string, unknown> & { nullifier_hash?: string; nullifierHash?: string };
  signal?: string;
};

async function hasDatabase(): Promise<boolean> {
  return Boolean(process.env.POSTGRES_URL || process.env.POSTGRES_PRISMA_URL);
}

async function ensureTables() {
  await sql`
    CREATE TABLE IF NOT EXISTS world_id_nullifiers (
      nullifier_hash TEXT PRIMARY KEY,
      action TEXT NOT NULL,
      signal TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS cyber_sentinels_audit_events (
      id BIGSERIAL PRIMARY KEY,
      event_type TEXT NOT NULL,
      trust_signal TEXT NOT NULL,
      action TEXT NOT NULL,
      nullifier_hash TEXT,
      signal TEXT,
      payload JSONB,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
}

export async function POST(request: Request) {
  try {
    const { proof, signal } = (await request.json()) as WorldIdVerifyBody;
    if (!proof) {
      return NextResponse.json({ verified: false, reason: "Missing World ID proof payload." }, { status: 400 });
    }

    const rpId = requiredEnv("WORLD_RP_ID");
    const action = WORLD_ACTION_ID;

    const worldResponse = await fetch(`${WORLD_VERIFY_BASE_URL}/api/v4/verify/${rpId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...proof, action, signal }),
      cache: "no-store",
    });

    const result = await worldResponse.json();

    if (!worldResponse.ok || !result?.success) {
      const output: CyberSentinelsWorldIdVerification = {
        verified: false,
        trustSignal: "world_id_proof_of_human",
        trustScoreContribution: 0,
        reason: result?.code ?? result?.detail ?? "World ID verification failed.",
        raw: result,
      };
      return NextResponse.json(output, { status: 400 });
    }

    const nullifierHash = String(result.nullifier_hash ?? proof.nullifier_hash ?? proof.nullifierHash ?? "");
    if (!nullifierHash) {
      return NextResponse.json({ verified: false, reason: "Missing nullifier hash in verified World ID result." }, { status: 400 });
    }

    if (await hasDatabase()) {
      await ensureTables();

      const existing = await sql`
        SELECT nullifier_hash FROM world_id_nullifiers
        WHERE nullifier_hash = ${nullifierHash}
        LIMIT 1
      `;

      if (existing.rowCount && existing.rowCount > 0) {
        return NextResponse.json({
          verified: false,
          trustSignal: "world_id_proof_of_human",
          trustScoreContribution: 0,
          nullifierHash,
          reason: "This World ID nullifier has already been used for this action.",
        }, { status: 409 });
      }

      await sql`
        INSERT INTO world_id_nullifiers (nullifier_hash, action, signal)
        VALUES (${nullifierHash}, ${action}, ${signal ?? null})
      `;

      await sql`
        INSERT INTO cyber_sentinels_audit_events (event_type, trust_signal, action, nullifier_hash, signal, payload)
        VALUES (
          ${"verified_human_world_id"},
          ${"world_id_proof_of_human"},
          ${action},
          ${nullifierHash},
          ${signal ?? null},
          ${JSON.stringify(result)}::jsonb
        )
      `;
    }

    const output: CyberSentinelsWorldIdVerification = {
      verified: true,
      trustSignal: "world_id_proof_of_human",
      trustScoreContribution: 35,
      nullifierHash,
      raw: result,
    };

    return NextResponse.json(output);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown verification error.";
    return NextResponse.json({ verified: false, reason: message }, { status: 500 });
  }
}
