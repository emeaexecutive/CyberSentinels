import WorldIdProofOfHuman from "@/components/WorldIdProofOfHuman";

export default function VerifyHumanPage() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,.14),transparent_24%),radial-gradient(circle_at_top_right,rgba(34,211,238,.12),transparent_22%),linear-gradient(180deg,#05070b,#071018_52%,#05070b)] px-6 py-12 text-white">
      <div className="mx-auto max-w-6xl">
        <header className="mb-6 rounded-[32px] border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl">
          <p className="text-xs uppercase tracking-[0.35em] text-cyan-300">Verified Human Flow</p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight md:text-6xl">Proof before permission.</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-300">
            Add this module into your Cyber Sentinels dashboard, candidate verification flow, contractor access workflow or investor demo.
          </p>
        </header>

        <WorldIdProofOfHuman />

        <section className="mt-6 grid gap-4 md:grid-cols-3">
          {[
            ["World ID", "Privacy-preserving proof that a unique human completed the check."],
            ["Cyber Sentinels", "Combines the proof with risk, device, trust graph and audit signals."],
            ["Trust Decision", "Approves, escalates or blocks access based on enterprise policy."],
          ].map(([title, text]) => (
            <div key={title} className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
              <h3 className="text-xl font-semibold">{title}</h3>
              <p className="mt-3 text-sm leading-6 text-slate-400">{text}</p>
            </div>
          ))}
        </section>
      </div>
    </main>
  );
}
