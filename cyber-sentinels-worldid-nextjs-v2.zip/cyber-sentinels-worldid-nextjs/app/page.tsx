import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,.16),transparent_24%),radial-gradient(circle_at_top_right,rgba(16,185,129,.16),transparent_22%),linear-gradient(180deg,#05070b,#071018_52%,#05070b)] px-6 py-20 text-white">
      <section className="mx-auto max-w-5xl rounded-[32px] border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl md:p-12">
        <p className="text-xs uppercase tracking-[0.35em] text-emerald-300">CYBER SENTINELS</p>
        <h1 className="mt-4 text-5xl font-semibold tracking-tight md:text-7xl">Verify Human before permission.</h1>
        <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
          This Next.js demo adds World ID proof-of-human as a trust signal inside the Cyber Sentinels verification flow.
        </p>
        <Link href="/verify-human" className="mt-8 inline-flex rounded-full bg-white px-6 py-3 font-semibold text-black">
          Start Verified Human Check
        </Link>
      </section>
    </main>
  );
}
