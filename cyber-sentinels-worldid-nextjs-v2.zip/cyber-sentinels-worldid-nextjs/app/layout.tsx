import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CYBER SENTINELS — Verified Human",
  description: "Proof-of-human verification for Cyber Sentinels trust infrastructure.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
