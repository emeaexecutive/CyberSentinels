import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cyber: {
          base: "#05070b",
          panel: "#0a111a",
          emerald: "#10b981",
          cyan: "#22d3ee"
        }
      }
    },
  },
  plugins: [],
};
export default config;
