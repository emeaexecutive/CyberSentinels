# CYBER SENTINELS — World ID Proof-of-Human Integration

Next.js / Vercel starter module for adding World ID proof-of-human verification into CYBER SENTINELS.

## What this gives you

- `/verify-human` — Cyber Sentinels verification screen
- `components/WorldIdProofOfHuman.tsx` — client widget
- `/api/world-id/verify` — backend proof verification route
- `/api/world-id/rp-signature` — backend RP signature route for World ID 4.0 flows
- Vercel Postgres tables for nullifier replay prevention and audit events

## Product role inside CYBER SENTINELS

World ID is used as one high-assurance signal:

`World ID proof-of-human + device intelligence + session risk + Trust Graph + audit log = Cyber Sentinels composite trust decision`

Do not position Cyber Sentinels as only a World ID integration. Position it as the enterprise trust infrastructure layer.

## Setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open:

```text
http://localhost:3000/verify-human
```

## World Developer Portal values

Create an app in the World Developer Portal and add:

```env
WORLD_APP_ID=app_staging_REPLACE_ME
WORLD_RP_ID=rp_staging_REPLACE_ME
WORLD_RP_SIGNING_KEY=replace_with_server_side_signing_key
WORLD_ACTION_ID=cyber_sentinels_verify_human
WORLD_VERIFY_BASE_URL=https://staging-developer.world.org
NEXT_PUBLIC_WORLD_APP_ID=app_staging_REPLACE_ME
NEXT_PUBLIC_WORLD_ACTION_ID=cyber_sentinels_verify_human
```

Use staging first, then production.

## Deploy to Vercel

1. Push this folder into your GitHub repo, e.g. `EMEAEXECUTIVES/CyberSentinels`.
2. Import repo into Vercel.
3. Add all environment variables in Vercel Project Settings.
4. Add Vercel Postgres if you want nullifier/audit persistence.
5. Deploy.

## SQL

If using Vercel Postgres, run the SQL in:

```text
sql/vercel-postgres.sql
```

The API route also auto-creates tables if the Vercel Postgres env vars exist.

## Important security notes

- Never expose `WORLD_RP_SIGNING_KEY` in the browser.
- Always verify the proof server-side.
- Always store/check `nullifier_hash` for replay prevention.
- Treat World ID as one trust signal, not the whole trust decision.
- Add your own enterprise policy layer before granting access.

## Next Cyber Sentinels extensions

- Add device fingerprinting signal.
- Add trust score calculation endpoint.
- Add enterprise policy decision engine.
- Add audit export pack.
- Add Trust Graph event streaming.
