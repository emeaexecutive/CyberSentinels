CREATE TABLE IF NOT EXISTS world_id_nullifiers (
  nullifier_hash TEXT PRIMARY KEY,
  action TEXT NOT NULL,
  signal TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cyber_sentinels_audit_events (
  id BIGSERIAL PRIMARY KEY,
  event_type TEXT NOT NULL,
  trust_signal TEXT NOT NULL,
  action TEXT NOT NULL,
  nullifier_hash TEXT,
  signal TEXT,
  payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
