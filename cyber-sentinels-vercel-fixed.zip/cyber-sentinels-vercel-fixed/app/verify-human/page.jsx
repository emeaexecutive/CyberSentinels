'use client';
import { useState } from 'react';
import PageShell from '@/components/PageShell';
import Card from '@/components/Card';

export default function VerifyHumanPage(){
 const [status,setStatus]=useState('Ready');
 async function runDemo(){setStatus('Proof request prepared. Connect World ID credentials in Vercel env to run live verification.');}
 const steps=['Identity intake','Liveness + face verification','Device + session intelligence','Trust decision'];
 return <PageShell><section className="mx-auto max-w-7xl px-6 py-10 lg:px-10"><div className="mb-8"><div className="text-xs uppercase tracking-[.35em] text-emerald-300">Verification Flow</div><h1 className="mt-3 text-4xl font-semibold">Prove identity before permission is granted.</h1><p className="mt-4 max-w-3xl text-slate-300">Use World ID as one proof-of-human signal, then combine it with Cyber Sentinels device, session, and audit intelligence.</p></div><div className="grid gap-6 lg:grid-cols-[.9fr_1.1fr]"><Card eyebrow="Session Journey" title="Verification steps"><div className="space-y-3">{steps.map((s,i)=><div key={s} className="rounded-2xl border border-white/10 bg-black/20 p-4"><span className="mr-3 text-emerald-300">0{i+1}</span>{s}</div>)}</div></Card><Card eyebrow="Proof of Human" title="World ID API Signal"><p>Status: <span className="text-emerald-300">{status}</span></p><button onClick={runDemo} className="mt-6 rounded-full bg-white px-5 py-3 text-sm font-semibold text-black">Prepare Proof Request</button><p className="mt-4 text-sm text-slate-400">Backend routes included: /api/world-id/rp-signature and /api/world-id/verify.</p></Card></div></section></PageShell>;
}
