import Link from 'next/link';
import PageShell from '@/components/PageShell';
import Card from '@/components/Card';

export default function HomePage() {
  const pillars = [
    ['Sentinel Identity™', 'Verify human identity with liveness, session intelligence, and anti-spoofing controls.'],
    ['Agent Passport™', 'Give autonomous AI agents origin, permissions, trust history, and accountability.'],
    ['Sentinel Score™', 'Score digital trust using identity, device, behaviour, and risk signals.'],
    ['Trust Graph™', 'Map relationships between people, agents, approvals, sessions, and threats.']
  ];

  return (
    <PageShell>
      <section className="mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-[1.1fr_.9fr] lg:px-10 lg:py-28">
        <div>
          <div className="mb-6 inline-flex rounded-full border border-emerald-400/20 bg-emerald-500/10 px-4 py-2 text-xs uppercase tracking-[0.28em] text-emerald-300">Identity for the AI era</div>
          <h1 className="text-5xl font-semibold leading-tight tracking-tight md:text-7xl">The trust layer for a world of <span className="bg-gradient-to-r from-white via-cyanglow to-emeraldx bg-clip-text text-transparent">deepfakes, autonomous agents, and synthetic identities.</span></h1>
          <p className="mt-8 max-w-2xl text-lg leading-8 text-slate-300">CYBER SENTINELS verifies humans, authenticates AI agents, scores digital trust, and gives organisations proof before permission.</p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link href="/verify-human" className="rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-black">Verify Human</Link>
            <Link href="/dashboard" className="rounded-full border border-white/10 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white">Open Dashboard</Link>
          </div>
        </div>
        <div className="glass rounded-[32px] p-6 shadow-cyan">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <div className="text-xs uppercase tracking-[0.3em] text-slate-400">Sentinel Console</div>
              <div className="mt-2 text-xl font-semibold">Trust Command Center</div>
            </div>
            <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs text-emerald-300">Live</span>
          </div>
          {[
            ['Verified Human', 'Remote candidate identity confirmed via liveness, device, and behavioral signals.', 'Trust 94'],
            ['Agent Passport', 'Origin verified, permissions restricted, anomalous behavior not detected.', 'Active'],
            ['Voice Clone Risk Detected', 'Executive authentication challenge triggered before transaction approval.', 'Blocked']
          ].map(([title, text, badge]) => (
            <div key={title} className="mt-4 rounded-2xl border border-white/10 bg-black/30 p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-lg font-medium">{title}</div>
                  <p className="mt-1 text-sm text-slate-400">{text}</p>
                </div>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-emerald-300">{badge}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="platform" className="border-y border-white/10 bg-black/20">
        <div className="mx-auto max-w-7xl px-6 py-20 lg:px-10">
          <div className="max-w-3xl">
            <div className="text-sm uppercase tracking-[0.3em] text-cyanglow">Platform</div>
            <h2 className="mt-4 text-4xl font-semibold tracking-tight md:text-5xl">Identity intelligence meets cyber governance.</h2>
            <p className="mt-6 text-lg leading-8 text-slate-300">Cyber Sentinels is trust infrastructure for humans, AI agents, and high-risk digital interactions.</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {pillars.map(([title, copy], index) => <Card key={title} eyebrow={`0${index + 1}`} title={title}>{copy}</Card>)}
          </div>
        </div>
      </section>
    </PageShell>
  );
}
