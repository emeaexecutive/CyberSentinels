import './globals.css';

export const metadata = {
  title: 'CYBER SENTINELS — Trust Layer for the Synthetic Age',
  description: 'Verify humans, authenticate AI agents, score digital trust, and protect high-risk interactions.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
