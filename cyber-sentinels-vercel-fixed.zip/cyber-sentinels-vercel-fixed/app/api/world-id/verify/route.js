import { NextResponse } from 'next/server';
import { assertWorldConfig } from '@/lib/world-id';

const seenNullifiers = new Set();

export async function POST(request) {
  try {
    const cfg = assertWorldConfig();
    const proofPayload = await request.json();

    if (!proofPayload?.nullifier_hash) {
      return NextResponse.json({ ok: false, error: 'Missing nullifier_hash' }, { status: 400 });
    }

    if (seenNullifiers.has(proofPayload.nullifier_hash)) {
      return NextResponse.json({ ok: false, error: 'Nullifier already used for this action' }, { status: 409 });
    }

    const verifyUrl = `${cfg.verifyBaseUrl}/${cfg.rpId}`;
    const response = await fetch(verifyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(proofPayload)
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return NextResponse.json({ ok: false, verified: false, world: data }, { status: response.status });
    }

    seenNullifiers.add(proofPayload.nullifier_hash);

    return NextResponse.json({
      ok: true,
      verified: true,
      trust_score: 94,
      source: 'world_id_proof_of_human',
      world: data
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  }
}
