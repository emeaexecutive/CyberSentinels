import { NextResponse } from 'next/server';
import { assertWorldConfig } from '@/lib/world-id';

export async function POST(request) {
  try {
    const { action = 'cyber_sentinels_verify_human', signal = 'verify-human' } = await request.json().catch(() => ({}));
    const cfg = assertWorldConfig();

    // This route intentionally keeps the signing key server-side.
    // Replace this demo signature object with the exact World Developer Portal signing flow for your app/RP.
    return NextResponse.json({
      ok: true,
      app_id: cfg.appId,
      rp_id: cfg.rpId,
      action,
      signal,
      request_id: `cs_${Date.now()}`,
      message: 'Server-side proof request prepared. Add World signing implementation once app credentials are active.'
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  }
}
