/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        base: '#05070b',
        panel: '#0b111a',
        emeraldx: '#19c37d',
        cyanglow: '#47c7ff'
      },
      boxShadow: {
        glow: '0 0 40px rgba(25,195,125,0.18)',
        cyan: '0 0 40px rgba(71,199,255,0.14)'
      }
    }
  },
  plugins: []
};
