import Link from 'next/link';

const links = [
  ['Platform', '/#platform'],
  ['Dashboard', '/dashboard'],
  ['Verify Human', '/verify-human'],
  ['Trust Graph', '/trust-graph'],
  ['Agent Passport', '/agent-passport']
];

export default function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/40 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl border border-emerald-400/20 bg-white/5 shadow-glow">
            <span className="text-sm font-semibold tracking-[0.3em] text-emerald-300">CS</span>
          </div>
          <div>
            <div className="text-xs uppercase tracking-[0.35em] text-slate-400">Cyber Sentinels</div>
            <div className="text-sm text-white/90">Trust Infrastructure</div>
          </div>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-slate-400 lg:flex">
          {links.map(([label, href]) => <Link key={label} href={href} className="hover:text-white">{label}</Link>)}
        </nav>
        <Link href="/verify-human" className="rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-black">Request Access</Link>
      </div>
    </header>
  );
}
