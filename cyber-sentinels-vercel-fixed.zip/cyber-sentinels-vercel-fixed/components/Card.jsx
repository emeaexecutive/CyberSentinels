export default function Card({ eyebrow, title, children, className = '' }) {
  return (
    <div className={`glass rounded-[28px] p-6 ${className}`}>
      {eyebrow ? <div className="text-xs uppercase tracking-[0.28em] text-emerald-300">{eyebrow}</div> : null}
      {title ? <h3 className="mt-3 text-2xl font-semibold text-white">{title}</h3> : null}
      {children ? <div className="mt-4 text-slate-300">{children}</div> : null}
    </div>
  );
}
