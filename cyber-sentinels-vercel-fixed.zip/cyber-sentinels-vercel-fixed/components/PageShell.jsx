import Nav from './Nav';

export default function PageShell({ children }) {
  return (
    <main className="min-h-screen bg-base text-white">
      <div className="fixed inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,rgba(71,199,255,0.16),transparent_26%),radial-gradient(circle_at_top_right,rgba(25,195,125,0.16),transparent_24%),linear-gradient(180deg,#05060a_0%,#071018_55%,#05060a_100%)]" />
      <div className="fixed inset-0 -z-10 grid-bg opacity-20" />
      <Nav />
      {children}
    </main>
  );
}
