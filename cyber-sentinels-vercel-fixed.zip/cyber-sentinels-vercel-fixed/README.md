# CYBER SENTINELS — Vercel Fixed Next.js Build

This replaces the broken mixed Create React App / static HTML / root JSX setup with a clean Next.js App Router structure for Vercel.

## Why the old build failed
- `package.json` used `react-scripts` / Create React App.
- React components were stored as root `.jsx` files, not inside `src` or a Next.js `app` structure.
- Some `.jsx` files in the repo appear converted into plain text/markdown fragments, so they cannot compile as React.
- Vercel was running `npm run build`, but the repository structure did not match the framework.

## Deploy
```bash
npm install
npm run build
npm run dev
```

## Vercel settings
- Framework preset: Next.js
- Build command: `npm run build`
- Install command: `npm install`
- Output directory: leave blank

## Environment variables
Copy `.env.example` to `.env.local` locally, and add the same values in Vercel Project Settings → Environment Variables.

## GitHub replacement steps
From the repo root:
```bash
# backup first if needed
rm -rf .github .vscode Bash public *.jsx index.html cyber-sentinels-worldid-nextjs-v2.zip
cp -R /path/to/cyber-sentinels-vercel-fixed/* .
git add .
git commit -m "Fix Vercel build with clean Next.js app"
git push origin main
```
